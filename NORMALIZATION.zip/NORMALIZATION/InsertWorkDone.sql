INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (16, 1, 1)
GO
INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (22, 2, 1)
GO
INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (27, 2, 2)
GO
INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (14, 3, 3)
GO
INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (33, 3, 4)
GO
INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (15, 4, 4)
GO
INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (21, 5, 5)
GO
INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (37, 5, 6)
GO
INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (11, 6, 7)
GO
INSERT INTO [dbo].[WorkDone]
           ([HoursDone]
           ,[EmployeeId]
           ,[ContractId])
     VALUES
           (25, 7, 7)
GO