INSERT INTO [dbo].[Employee]
           ([SocialSecurityNumber]
           ,[Name])
     VALUES
           (N'051159-056G', N'Adela Banner')
GO
INSERT INTO [dbo].[Employee]
           ([SocialSecurityNumber]
           ,[Name])
     VALUES
           (N'110684-0056', N'Ellis Holt')
GO
INSERT INTO [dbo].[Employee]
           ([SocialSecurityNumber]
           ,[Name])
     VALUES
           (N'110682-112F', N'Ralf Cockburn')
GO
INSERT INTO [dbo].[Employee]
           ([SocialSecurityNumber]
           ,[Name])
     VALUES
           (N'081169-167S', N'Jerome Palmer')
GO
INSERT INTO [dbo].[Employee]
           ([SocialSecurityNumber]
           ,[Name])
     VALUES
           (N'230899-178K', N'Hammond Danniel')
GO
INSERT INTO [dbo].[Employee]
           ([SocialSecurityNumber]
           ,[Name])
     VALUES
           (N'031295-132D', N'Cathleen Forrest')
GO
INSERT INTO [dbo].[Employee]
           ([SocialSecurityNumber]
           ,[Name])
     VALUES
           (N'073078-234N', N'Kimmy Terrell')
GO

