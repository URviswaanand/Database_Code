INSERT INTO [dbo].[Target]
           ([Name]
           ,[Address])
     VALUES
           (N'Mikpoli', N'Patteristonkatu 3')
GO
INSERT INTO [dbo].[Target]
           ([Name]
           ,[Address])
     VALUES
           (N'Päämajakoulu', N'Otto Mannisenkatu 10')
GO
INSERT INTO [dbo].[Target]
           ([Name]
           ,[Address])
     VALUES
           (N'Akseli', N'Hallituskatu 7-9')
GO
INSERT INTO [dbo].[Target]
           ([Name]
           ,[Address])
     VALUES
           (N'Elomaan Talo', N'Pirttiniemenkatu 7')
GO
INSERT INTO [dbo].[Target]
           ([Name]
           ,[Address])
     VALUES
           (N'Mikkelin Kuntopalvelu', N'Savilahdenkatu 16')
GO
INSERT INTO [dbo].[Target]
           ([Name]
           ,[Address])
     VALUES
           (N'Mikkelin I Apteekki', N'Porrassalmenkatu 1')
GO
INSERT INTO [dbo].[Target]
           ([Name]
           ,[Address])
     VALUES
           (N'RengasCenter', N'Juvantie 77')
GO

