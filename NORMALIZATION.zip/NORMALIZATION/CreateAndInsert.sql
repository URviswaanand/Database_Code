IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'NORMALIZATION')
    CREATE database NORMALIZATION
ELSE
	PRINT 'You already have database NORMALIZATION created.'
GO
USE [NORMALIZATION]
GO
:setvar path "C:\Users\Student\Documents\SQL Server Management Studio\NORMALIZATION\"
:r $(path)\CreateEmployee.sql
:r $(path)\CreateTarget.sql
:r $(path)\CreateContract.sql
:r $(path)\CreateWorkDone.sql
:r $(path)\InsertEmployee.sql
:r $(path)\InsertTarget.sql
:r $(path)\InsertContract.sql
:r $(path)\InsertWorkDone.sql