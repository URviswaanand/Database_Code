1. Who cleaned Elomaan talo?

SELECT Name
FROM Employee
WHERE Id IN (SELECT EmployeeId
FROM WorkDone
WHERE ContractId=(SELECT Id
FROM Contract
WHERE TargetId=(SELECT Id
FROM Target
WHERE Name LIKE '%Elomaa%')));