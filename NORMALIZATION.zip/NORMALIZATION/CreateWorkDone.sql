SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[WorkDone](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[HoursDone] [int] NOT NULL,
	[EmployeeId] [int] NOT NULL,
	[ContractId] [int] NOT NULL,
 CONSTRAINT [PK_WorkDone] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[WorkDone]  WITH CHECK ADD  CONSTRAINT [FK_WorkDone_Contract] FOREIGN KEY([ContractId])
REFERENCES [dbo].[Contract] ([Id])
GO

ALTER TABLE [dbo].[WorkDone] CHECK CONSTRAINT [FK_WorkDone_Contract]
GO

ALTER TABLE [dbo].[WorkDone]  WITH CHECK ADD  CONSTRAINT [FK_WorkDone_Employee] FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Employee] ([Id])
GO

ALTER TABLE [dbo].[WorkDone] CHECK CONSTRAINT [FK_WorkDone_Employee]
GO