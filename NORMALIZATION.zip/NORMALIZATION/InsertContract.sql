INSERT INTO [dbo].[Contract]
           ([ContractNumber]
           ,[TargetId])
     VALUES
           (N'201801', 1)
GO
INSERT INTO [dbo].[Contract]
           ([ContractNumber]
           ,[TargetId])
     VALUES
           (N'201802', 2)
GO
INSERT INTO [dbo].[Contract]
           ([ContractNumber]
           ,[TargetId])
     VALUES
           (N'201803', 3)
GO
INSERT INTO [dbo].[Contract]
           ([ContractNumber]
           ,[TargetId])
     VALUES
           (N'201804', 4)
GO
INSERT INTO [dbo].[Contract]
           ([ContractNumber]
           ,[TargetId])
     VALUES
           (N'201805', 5)
GO
INSERT INTO [dbo].[Contract]
           ([ContractNumber]
           ,[TargetId])
     VALUES
           (N'201806', 6)
GO
INSERT INTO [dbo].[Contract]
           ([ContractNumber]
           ,[TargetId])
     VALUES
           (N'201807', 7)
GO