USE [ForeignKey]
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 3, 1, 4)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 4, 1, 3)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 5, 1, 5)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 7, 2, 5)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 6, 2,6)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 5, 2, 7)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 4, 3, 2)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 3, 3, 3)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 2, 3, 4)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 4, 4, 1)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 6, 4, 2)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 1, 4, 3)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 3, 5, 7)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 4, 5, 5)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 6, 5, 3)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 7, 6, 1)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 2, 6, 5)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 4, 6, 7)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 6, 7, 1)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 5, 7, 1)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 4, 7, 1)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 3, 8, 4)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 2, 8, 3)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 7, 8, 2)
GO

INSERT INTO [dbo].[Order]
           ([OrderNumber]
           ,[Amount]
           ,[ClientId]
           ,[ProductId])
     VALUES
           (NEWID(), 1, 8, 1)
GO
