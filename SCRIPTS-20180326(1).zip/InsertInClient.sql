USE [ForeignKey]
GO

INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName])
     VALUES
           (N'Bigtime', N'Beagle')
GO

INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName])
     VALUES
           (N'Daisy', N'Duck')
GO

INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName])
     VALUES
           (N'Doofus', N'Drake')
GO

INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName])
     VALUES
           (N'Elmer', N'Elephant')
GO

INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName])
     VALUES
           (N'Roger', N'Radcliff')
GO

INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName])
     VALUES
           (N'Scrooge', N'McDuck')
GO

INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName])
     VALUES
           (N'Gyro', N'Gearloose')
GO

INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName])
     VALUES
           (N'Newton', N'Gearloose')
GO

