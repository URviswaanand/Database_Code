USE [ForeignKey]
GO

INSERT INTO [dbo].[Product]
           ([Name])
     VALUES
           (N'Cooking Chef')
GO

INSERT INTO [dbo].[Product]
           ([Name])
     VALUES
           (N'Citrus Press')
GO

INSERT INTO [dbo].[Product]
           ([Name])
     VALUES
           (N'Glass Kettle')
GO

INSERT INTO [dbo].[Product]
           ([Name])
     VALUES
           (N'Hand Blender')
GO

INSERT INTO [dbo].[Product]
           ([Name])
     VALUES
           (N'Cutting Board')
GO

INSERT INTO [dbo].[Product]
           ([Name])
     VALUES
           (N'Swivel Peeler')
GO

INSERT INTO [dbo].[Product]
           ([Name])
     VALUES
           (N'Can Opener')
GO

