-- REMEMBER UTF-8 ENCODING
IF NOT EXISTS (SELECT * FROM Branch)
BEGIN
	INSERT INTO [dbo].[Branch]
           ([Street]
           ,[City]
           ,[Postcode])
     VALUES
           (N'22 Deer Road', N'London', N'SW1 4EH')

	INSERT INTO [dbo].[Branch]
           ([Street]
           ,[City]
           ,[Postcode])
     VALUES
           (N'16 Argyll Street', N'Aberdeen', N'AB2 3SU')

	INSERT INTO [dbo].[Branch]
           ([Street]
           ,[City]
           ,[Postcode])
     VALUES
           (N'163 Main Street', N'Glasgow', N'G11 9QX')

	INSERT INTO [dbo].[Branch]
           ([Street]
           ,[City]
           ,[Postcode])
     VALUES
           (N'32 Manse Road', N'Bristol', N'BS99 1NZ')

	INSERT INTO [dbo].[Branch]
           ([Street]
           ,[City]
           ,[Postcode])
     VALUES
           (N'56 Clover Drive', N'London', N'NW10 6EU')
	PRINT 'Information added successfully to table Branch.'
END
ELSE
	PRINT 'You already have the Branch information added.'