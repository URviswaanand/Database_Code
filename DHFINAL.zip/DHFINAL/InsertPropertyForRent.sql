-- REMEMBER UTF-8 ENCODING
IF NOT EXISTS (SELECT * FROM PropertyForRent)
BEGIN
	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'16 Holhead', N'Aberdeen', N'AB7 5SU', N'House', 6, 650, 1, 4, 2)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'6 Argyll Street', N'London', N'NW2 3EN', N'Flat', 4, 400, 2, 2, 1)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Slippery Lane 16', N'London', N'B52 5CD', N'Villa', 5, 1135, 2, 2, 1)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'3 Argyll Street', N'London', N'RW5 7EN', N'Villa', 7, 900, 2, 2, 1)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'6 Lawrence Street', N'Glasgow', N'G11 9QX', N'Flat', 3, 350, 3, 7, 3)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'2 Manor Road', N'Glasgow', N'K32 4QX', N'Flat', 3, 375, 4, 7, 3)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'18 Dale Road', N'Glasgow', N'X12 SW91', N'House', 5, 600, 2, 7, 3)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'5 Novar Drive', N'Glasgow', N'M12 9AX', N'Flat', 4, 450, 4, 7, 3)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Stoke Hill', N'Bristol', N'Q16 9JX', N'Villa', 7, 750, 4, 10, 4)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'8 Naval Drive', N'Bristol', N'F18 2AL', N'Bungalow', 4, 975, 4, 10, 4)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'5 Sunset Boulevard', N'Bristol', N'A12 9AX', N'Cottage', 4, 450, 4, 10, 4)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Fleet Street 10', N'Aberdeen', N'L42 9AX', N'House', 5, 650, 1, NULL, 2)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Christmas Pie Avenue 11', N'Bristol', N'S55 3AY', N'Cottage', 4, 435, 1, NULL, 2)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Honeypot Lane 15', N'Glasgow', N'T57 2CX', N'Bungalow', 4, 955, 3, NULL, 1)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Southbank Avenue 3', N'Glasgow', N'H66 2CL', N'Bungalow', 6, 825, 4, 7, 3)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Montague Street 35', N'Glasgow', N'E55 7CX', N'Bungalow', 4, 810, 3, 7, 3)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Havelock Lane 11', N'Glasgow', N'S10 6AA', N'Cottage', 4, 610, 2, 7, 3)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Claremont Gardens 8', N'Glasgow', N'T33 8GB', N'Bungalow', 5, 990, 4, 7, 3)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Urguhart Road 12', N'Aberdeen', N'K88 6CV', N'House', 4, 780, 7, 4, 2)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Crimon Plaza 65', N'Aberdeen', N'S99 1KK', N'House', 4, 810, 7, 4, 2)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Froghart Terrace 26', N'Aberdeen', N'T52 4JS', N'House', 4, 850, 7, 4, 2)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Rickman Drive 9', N'Bristol', N'D44 5YY', N'Villa', 6, 810, 6, 10, 4)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Lytham Croft 14', N'Bristol', N'L71 8UU', N'Villa', 5, 780, 6, 10, 4)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Wretham Street 6', N'Bristol', N'W93 2BG', N'Villa', 5, 940, 5, 10, 4)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Chiswick High Street 15', N'London', N'T44 3CK', N'Villa', 5, 1450, 10, 20, 5)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Uxbridge Road 55', N'London', N'S34 2CX', N'Villa', 6, 1170, 9, 20, 5)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Prince Consort Road 26', N'London', N'V65 6KK', N'Villa', 5, 1365, 8, 20, 5)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Eaton Terrace 99', N'London', N'T34 6CJ', N'Villa', 4, 1155, 8, 20, 5)

	INSERT INTO [dbo].[PropertyForRent]
           ([Street]
           ,[City]
           ,[Postcode]
           ,[TypeOfProperty]
           ,[NumberOfRooms]
           ,[Rent]
           ,[PrivateOwnerId]
           ,[StaffId]
           ,[BranchId])
     VALUES
           (N'Willow Walk 15', N'London', N'P77 7UU', N'Bungalow', 6, 1560, 9, 20, 5)
	PRINT 'Information added successfully to table PropertyForRent.'
END
ELSE
	PRINT 'You already have the PropertyForRent information added.'