-- REMEMBER UTF-8 ENCODING
IF NOT EXISTS (SELECT * FROM Viewing)
BEGIN
	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (2, 2, '2018-03-24', N'"too small for a family like us"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (1, 5, '2018-04-20', N'"too remote without having a car"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (2, 8, '2018-05-26', NULL)

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (4, 1, '2018-05-14', N'"no proper dining room"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (2, 6, '2018-05-28', NULL)

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (3, 7, '2018-05-26', N'"no parking place provided"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (5, 5, '2018-06-13', N'"architectural structure obscure"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (6, 6, '2018-06-14', N'"Not possible to commute by train"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (7, 15, '2018-06-15', NULL)

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (8, 19, '2018-06-16', N'"Information about security deposit?"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (9, 20, '2018-06-17', N'"Hidden fees seems to pop up."')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (10, 22, '2018-06-16', N'"The best views can be seen from the roof."')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (11, 23, '2018-06-15', N'"Did not realize how small the kitchen is"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (12, 24, '2018-06-14', N'"Not enough storage space"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (13, 25, '2018-06-13', NULL)

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (14, 17, '2018-06-12', N'"The grass outside is full of neighbors with dogs."')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (15, 28, '2018-03-24', NULL)

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (16, 29, '2018-04-20', NULL)

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (17, 11, '2018-05-26', N'"Neighbors seem to be professional noisemakers."')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (11, 24, '2018-05-26', NULL)

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (17, 13, '2018-06-15', NULL)

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (15, 25, '2018-06-15', N'"Any penalties for moving out before the expiration date?"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (4, 7, '2018-06-15', N'"Air conditioner looked suspicious?"')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (11, 25, '2018-06-15', N'"Quality and prize seems to go hand in hand."')

	INSERT INTO [dbo].[Viewing]
           ([ClientId]
           ,[PropertyForRentId]
           ,[ViewDate]
           ,[CommentsGiven])
     VALUES
           (7, 14, '2018-06-15', NULL)
	PRINT 'Information added successfully to table Viewing.'
END
ELSE
	PRINT 'You already have the Viewing information added.'