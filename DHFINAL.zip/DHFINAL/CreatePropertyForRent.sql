IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_NAME = N'PropertyForRent')
BEGIN
	SET ANSI_NULLS ON
	SET QUOTED_IDENTIFIER ON

	CREATE TABLE [dbo].[PropertyForRent](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Street] [nvarchar](50) NOT NULL,
		[City] [nvarchar](50) NOT NULL,
		[Postcode] [nvarchar](50) NOT NULL,
		[TypeOfProperty] [nvarchar](50) NOT NULL,
		[NumberOfRooms] [int] NOT NULL,
		[Rent] [decimal](8, 2) NOT NULL,
		[PrivateOwnerId] [int] NOT NULL,
		[StaffId] [int] NULL,
		[BranchId] [int] NOT NULL,
	CONSTRAINT [PK_PropertyForRent] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[PropertyForRent]  WITH CHECK ADD  CONSTRAINT [FK_PropertyForRent_Branch] FOREIGN KEY([BranchId])
	REFERENCES [dbo].[Branch] ([Id])

	ALTER TABLE [dbo].[PropertyForRent] CHECK CONSTRAINT [FK_PropertyForRent_Branch]

	ALTER TABLE [dbo].[PropertyForRent]  WITH CHECK ADD  CONSTRAINT [FK_PropertyForRent_PrivateOwner] FOREIGN KEY([PrivateOwnerId])
	REFERENCES [dbo].[PrivateOwner] ([Id])

	ALTER TABLE [dbo].[PropertyForRent] CHECK CONSTRAINT [FK_PropertyForRent_PrivateOwner]

	ALTER TABLE [dbo].[PropertyForRent]  WITH CHECK ADD  CONSTRAINT [FK_PropertyForRent_Staff] FOREIGN KEY([StaffId])
	REFERENCES [dbo].[Staff] ([Id])

	ALTER TABLE [dbo].[PropertyForRent] CHECK CONSTRAINT [FK_PropertyForRent_Staff]
	PRINT 'Table PropertyForRent successfully created.'
END
ELSE
	PRINT 'You already have table PropertyForRent created.'