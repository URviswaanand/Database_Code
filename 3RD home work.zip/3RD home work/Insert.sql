INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DayOfBirth]
           ,[Salary])
     VALUES
           (N'Mickey', N'Mouse', N'Manager', 'M', '1989-11-23', 3456.95)
GO

INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DayOfBirth]
           ,[Salary])
     VALUES
           (N'Scrooge', N'McDuck', N'Senior Chairman', 'M', '1956-07-17', 5451.35)
GO

INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DayOfBirth]
           ,[Salary])
     VALUES
           (N'Donald', N'Duck', N'Senior Real Estate Specialist', 'M', '1984-12-09', 2756.45)
GO

INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DayOfBirth]
           ,[Salary])
     VALUES
           (N'Big Bad', N'Wolf', N'Certified Fraud Examiner', 'M', '1949-05-29', 4114.15)
GO

INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DayOfBirth]
           ,[Salary])
     VALUES
           (N'Gyro', N'Gearloose', N'Group Account Manager', 'M', '1969-03-17', 2139.25)
GO

INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DayOfBirth]
           ,[Salary])
     VALUES
           (N'Newton', N'Gearloose', N'Biomedical Engineer', 'M', '1944-09-30', 4119.35)
GO

INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DayOfBirth]
           ,[Salary])
     VALUES
           (N'Ludwig', N'von Drake', N'Front Desk Specialist', 'M', '1972-04-14', 3612.75)
GO

INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DayOfBirth]
           ,[Salary])
     VALUES
           (N'Minnie', N'Mouse', N'Senior Credit Analyst', 'F', '1971-08-24', 2652.95)
GO

INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DayOfBirth]
           ,[Salary])
     VALUES
           (N'Daisy', N'Duck', N'Law Enforcement Teacher', 'F', '1967-09-03', 4017.55)
GO

